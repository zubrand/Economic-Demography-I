setwd("D:/OneDrive/VSE/II/Economic Demography I/Project Norway")
rm(list = ls())

# Libraries
library(dplyr)
library(reshape2)

## Marital Status ----
# Wide to High
read.csv("Data/Eurostat/Norway_Marital.csv", sep=";", na.strings="") %>%
  melt(id.vars = c("Age", "Sex", "Year")) %>% 
  setNames(c("Age", "Sex", "Year", "Marsta", "Count")) %>% return %>%
  write.csv(file = "Data/Norway_Marital_v2.csv", row.names = F)


## Education Level ----
# Wide to High
read.csv("Data/Eurostat/Norway_Education.csv", sep=";", na.strings="") %>%
  melt(id.vars = c("Age", "Sex", "Year")) %>% 
  setNames(c("Age", "Sex", "Year", "Education", "Count")) %>% return %>%
  write.csv(file = "Data/Norway_Education_v2.csv", row.names = F)  

## Data import ----
dt_Population_general <- read.csv("Data/Norway_Population_general.csv", sep=";")
dt_Population_Age_Sex <- read.csv("Data/Norway_Population_Age_Sex.csv", sep=";", na.strings = ":", dec = ",")
dt_Migration <- read.csv("Data/Norway_Migration.csv", sep=";")
dt_Marriage_PrevStatus <- read.csv("Data/Norway_Marriage_PrevStatus.csv", sep=";")
dt_Marriage_Age <- read.csv("Data/Norway_Marriage_Age.csv", sep=";")
dt_Marital <- read.csv("Data/Norway_Marital_v2.csv")
dt_Life_Table <- read.csv("Data/Norway_Life_Table.csv", sep=";", dec = ",")
dt_Fertility_Rate <- read.csv("Data/Norway_Fertility_rate.csv", sep=";", dec = ",")
dt_Fertility_Age_Sex <- read.csv("Data/Norway_Fertility_Age_Sex.csv", sep=";", dec = ",")
dt_Fertility <- read.csv("Data/Norway_Fertility.csv", sep=";", dec = ",")
dt_Education <- read.csv("Data/Norway_Education_v2.csv")
dt_Divorce <- read.csv("Data/Norway_Divorce.csv", sep=";", dec = ",")
dt_Death_Age <- read.csv("Data/Norway_Death_Age.csv", sep=";")

## Save to RData ----
save.image(file = 'Data/Eurostat.RData')
