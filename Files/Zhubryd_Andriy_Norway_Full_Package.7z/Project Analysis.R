setwd("D:/OneDrive/VSE/II/Economic Demography I/Project Norway")
rm(list = ls())

## Preparation ----
# Libraries
library(dplyr)      # Work with datasets: filter, group, summarize
library(reshape2)   # Transformation of datasets: wide-to-long format and vice versa
library(pyramid)    # Visualization of demography pyramid
library(ggplot2)    # Building graphs
library(scales)     # Number formatting

# Data
load('Data/Eurostat.RData') # Preprocessed data from Eurostat | Norway only

## Part 1 ----
## Population Size
dt_Population_Age_Sex %>% 
  group_by(Year) %>% summarize(Population = sum(Population, na.rm = T)) %>%
  ggplot(aes(x = Year, y = Population)) + geom_point(size = 3) +
    geom_line() + scale_y_continuous(limits = c(0, 6*10^6), labels = comma) +
    ggtitle("Development of Norway's population in time")

dt_Population_Age_Sex %>% 
  group_by(Year, Sex) %>% summarize(Population = sum(Population, na.rm = T)) %>%
  ggplot(aes(x = Year, y = Population, color = Sex)) + geom_point(size = 3) +
  geom_line() + scale_y_continuous(limits = c(0, 3*10^6), labels = comma) +
  ggtitle("Development of Norway's population in time by sex")

## Part 2 ----
## Population Structure
dt_Population_Age_Sex %>% 
  filter(Year == 1960) %>% group_by(Age, Sex) %>% summarise(value = sum(Population, na.rm = T)) %>%
  dcast(Age ~ Sex, fun.aggregate = sum, value.var = "value") %>% select(M, F, Age) %>%
  pyramid(Csize = 1, Cstep = 5, AxisFM = 'd', Cgap = .1, Laxis = 10^4 * 0:4,
          main = "Pyramid of Norway's population in 1960")

dt_Population_Age_Sex %>% 
  filter(Year == 1980) %>% group_by(Age, Sex) %>% summarise(value = sum(Population, na.rm = T)) %>%
  dcast(Age ~ Sex, fun.aggregate = sum, value.var = "value") %>% select(M, F, Age) %>%
  pyramid(Csize = 1, Cstep = 5, AxisFM = 'd', Cgap = .1, Laxis = 10^4 * 0:4,
          main = "Pyramid of Norway's population in 1980")

dt_Population_Age_Sex %>% 
  filter(Year == 2000) %>% group_by(Age, Sex) %>% summarise(value = sum(Population, na.rm = T)) %>%
  dcast(Age ~ Sex, fun.aggregate = sum, value.var = "value") %>% select(M, F, Age) %>%
  pyramid(Csize = 1, Cstep = 5, AxisFM = 'd', Cgap = .1, Laxis = 10^4 * 0:4,
          main = "Pyramid of Norway's population in 2000")

dt_Population_Age_Sex %>% 
  filter(Year == 2013) %>% group_by(Age, Sex) %>% summarise(value = sum(Population, na.rm = T)) %>%
  dcast(Age ~ Sex, fun.aggregate = sum, value.var = "value") %>% select(M, F, Age) %>%
  pyramid(Csize = 1, Cstep = 5, AxisFM = 'd', Cgap = .1, Laxis = 10^4 * 0:4,
          main = "Pyramid of Norway's population in 2013")

Indeces!!! Masculinity

# Biological generations
tmp_Population_Age_Sex_Gen <- dt_Population_Age_Sex %>% 
  mutate(Gen_bio = cut(Age, include.lowest = T, breaks = c(0, 15, 50, 100), right = F),
         Gen_eco = cut(Age, include.lowest = T, breaks = c(0, 20, 65, 100), right = F))

tmp_Bio_Generation <- tmp_Population_Age_Sex_Gen %>%
  group_by(Year, Generation = Gen_bio) %>% summarize(Value = sum(Population, na.rm = T)) %>%
  merge(dt_Population_Age_Sex %>% group_by(Year) %>% summarize(pop = sum(Population, na.rm = T)), by = "Year") %>%
  mutate(Share = Value/pop) %>% select(Year, Generation, Share)

tmp_Bio_Generation %>% 
  ggplot(aes(x = Year, y = Share, color = Generation, fill = Generation)) +
    geom_area() + ggtitle("Development of Biological generations in Time\nNorway")

tmp_Bio_Generation %>% filter(Year == 2013) %>%
  ggplot(aes(x = "", y = Share, fill = Generation)) +
    geom_bar(width = 1, stat = "identity") + coord_polar(theta = "y", start = 0) + 
    ggtitle("Norwish population by Biological generations in 2013")

tmp_Bio_Generation %>% filter(Year == 2013) %>% mutate(Share = round(Share*100, digits = 1))

# Economical Generations
tmp_Eco_Generation <- tmp_Population_Age_Sex_Gen %>%
  group_by(Year, Generation = Gen_eco) %>% summarize(Value = sum(Population, na.rm = T)) %>%
  merge(dt_Population_Age_Sex %>% group_by(Year) %>% summarize(pop = sum(Population, na.rm = T)), by = "Year") %>%
  mutate(Share = Value/pop) %>% select(Year, Generation, Share)

tmp_Eco_Generation %>% 
  ggplot(aes(x = Year, y = Share, color = Generation, fill = Generation)) +
  geom_area() + ggtitle("Development of Economical generations in Time\nNorway")

tmp_Eco_Generation %>% filter(Year == 2013) %>%
  ggplot(aes(x = "", y = Share, fill = Generation)) +
  geom_bar(width = 1, stat = "identity") + coord_polar(theta = "y", start = 0) + 
  ggtitle("Norwish population by Economical generations in 2013")

tmp_Eco_Generation %>% filter(Year == 2013) %>% mutate(Share = round(Share*100, digits = 1))          

